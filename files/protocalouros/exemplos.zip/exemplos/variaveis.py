ex = 15
print ex
print ex/3
print ex+6
soma = ex+17
print soma
soma = soma + ex + 6
print soma
print soma % 10
print soma % ex
a = 1
b = 4
c = -5
delta = b*b - 4*a*c
print delta
