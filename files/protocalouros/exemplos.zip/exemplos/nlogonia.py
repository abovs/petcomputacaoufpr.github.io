n = int(input())

while n:
	x, y = raw_input().split()

	x = int(x)
	y = int(y)

	while n > 0:
		i, j = raw_input().split()
	
		i = int(i)
		j = int(j)
	
		if x == i or y == j:
			print "divisa"
		
		if x > i and y > j:
			print "SO"
			
		if x > i and y < j:
			print "NO"
		
		if x < i and y > j:
			print "SE"
		
		if x < i and y < j:
			print "NE"
		
		n = n-1
	
	n = int(input())
