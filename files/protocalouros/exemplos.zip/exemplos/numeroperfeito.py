n = int(input())

soma = 0

i = 1

while n > i:
	if (n % i) == 0: # se n é divisível por i
		soma = soma + i

	i = i+1
	
	
if soma == n:
	print "é perfeito"
else:
	print "não é perfeito"
