from math import sqrt

a, b, c = raw_input().split(' ')

while a != '0' and b != '0' and c != '0' :
	a = int(a)
	b = int(b)
	c = int(c)
	
	delta = b*b - 4*a*c

	if delta > 0:
		x1 = (-b + sqrt(delta))/(2*a)
		x2 = (-b - sqrt(delta))/(2*a)
		print x1, x2

	elif delta == 0:
		x = (-b + sqrt(delta))/(2*a)
		print x
	else:
		print "nao existem raizes reais"
		
	a, b, c = raw_input().split(' ')
