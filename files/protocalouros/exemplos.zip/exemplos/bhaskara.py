from math import sqrt

a, b, c = raw_input().split(' ')

delta = b*b - 4*a*c

if delta > 0:
	x1 = (-b + sqrt(delta))/(2*a)
	x2 = (-b - sqrt(delta))/(2*a)
	print x1, x2

if delta == 0:
	x1 = (-b + sqrt(delta))/(2*a)
	print x1

if delta < 0:
	print "nao existem raizes reais"
